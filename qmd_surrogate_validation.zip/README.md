# QMD Surrogate Validation Framework

This repository contains the code used to evaluate the DE4-based Quantum Motor Dynamics (QMD) surrogate model.
It includes:
- **Core Surrogate Comparison Module** for true vs. learned DE4 outputs.
- **Automatic Post-Run Summary** (plots + numerical metrics + Drive autosave).
- **Sample Logs & Results** from Paper 4 experiments.

## Quick Start

```bash
conda env create -f environment.yml
conda activate qmd_surrogate
python de4_postrun_summary.py
```

Alternatively, open `qmd_surrogate_test.ipynb` in Google Colab for a one-click workflow.

## Outputs
- `de4_fidelity_summary.csv` — correlation, MSE, and MAE metrics.
- `de4_postrun_summary.png` — visual alignment between true and surrogate data.
- Auto-save to Google Drive if mounted.
