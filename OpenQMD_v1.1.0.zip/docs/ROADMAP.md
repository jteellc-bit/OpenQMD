# OpenQMD ROADMAP
Version 1.1.0 — October 2025

## Module Updates
- Added `/modules/thermal/tests/THERMAL_VALIDATION_PROTOCOL.md`.
- Integrated adaptive thermal feedback testing into QMD recursion model.

## Upcoming
- Thermal feedback integration into OpenQMD simulation.
- Machine-learning assisted control optimization.
