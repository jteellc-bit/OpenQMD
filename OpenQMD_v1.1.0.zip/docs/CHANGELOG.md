# CHANGELOG
## [1.1.0] - 2025-10-20
### Added
- THERMAL_VALIDATION_PROTOCOL.md under /modules/thermal/tests/
- Updated ROADMAP and CHANGELOG for v1.1.0 release.
