# motor_3x3_coupled_synthetic

This repository demonstrates a synthetic 3×3 phase-coupled motor simulation
with a lightweight surrogate model trained via synthetic data, suitable for
testing Model Predictive Control (MPC) logic. No external datasets required.

### Files
- `motor_3x3_surrogate_controller.py` — Surrogate + MPC logic
- `motor_3x3_simulation.ipynb` — Notebook to run the full demo
- `motor_3x3_design_notes.md` — Design + physics notes
- `/results` — Saved model + metrics + plots
